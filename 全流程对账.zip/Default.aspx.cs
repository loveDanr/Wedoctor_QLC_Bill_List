﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Reflection;
using System.Collections;
using System.IO;




public partial class _Default : System.Web.UI.Page 
{
    public string start; public string end; public string testTime;
    protected void Page_Load(object sender, EventArgs e)
    {
            testTime = "2018-06-19";
            start = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
            end = DateTime.Now.ToString("yyyy-MM-dd");
        
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        WedoctorFileData wd = new WedoctorFileData();
        //string _requesthis = gethisReq(txtStartTime.ToString(), txtEndTime.ToString());
        List<string> _request = getReq(testTime, testTime);
        RefreshCheckData(_request);
    }
  
     
    protected void GridView_DataBinding(object sender, EventArgs e)
    {
    }
    private int sum_totalCount = 0;
    private decimal sum_TotalGet = 0;
    protected void GridView_RowDataBound(object sender,GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
        {
            //保持列不变形
            for (int i = 0; i < e.Row.Cells.Count; i++)
            {
                //方法一：
                e.Row.Cells[i].Text = e.Row.Cells[i].Text;
                e.Row.Cells[i].Wrap = false;
                //方法二：
                //e.Row.Cells[i].Text = "<nobr>&nbsp;" + e.Row.Cells[i].Text + "&nbsp;</nobr>";            
            }
            
        }
        //如果是绑定数据行 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //鼠标经过时，行背景色变 
            e.Row.Attributes.Add("onmouseover", "this.style.backgroundColor='#E6F5FA'");
            //鼠标移出时，行背景色变 
            e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor='#FFFFFF'");

        }

        if (e.Row.RowIndex >= 0)
        {

            
            sum_TotalGet += Convert.ToDecimal(e.Row.Cells[8].Text);
             
        }
        else if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[1].Text = sum_totalCount.ToString("F2");
            e.Row.Cells[3].Text = sum_TotalGet.ToString("F2");

        }
    }
    protected void GridView_RowCreated(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            TableCellCollection tcc = e.Row.Cells;
            tcc.Clear();
            e.Row.Cells.Add(new TableCell());
            e.Row.Cells[0].Attributes.Add("colspan", "4");
            e.Row.Cells[0].Text = "合计";
            e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Center;
            e.Row.Cells.Add(new TableCell());

            e.Row.Cells[1].Text = "";//
            e.Row.Cells.Add(new TableCell());

            e.Row.Cells[2].Text = "总收入";//
            e.Row.Cells.Add(new TableCell());

            e.Row.Cells[3].Text = "";//
            e.Row.Cells.Add(new TableCell());
            e.Row.Cells.Add(new TableCell());
            e.Row.Cells[4].Attributes.Add("colspan", "13");
            e.Row.Cells[4].Text = "";
            e.Row.Cells[4].HorizontalAlign = HorizontalAlign.Center;
            e.Row.Cells.Add(new TableCell());
        }
    }
     
protected void  download_btn_Click(object sender, EventArgs e)
{
    //toExcel(GridView);
    
}

    #region  刷新数据明细数据
    /// <summary>
    /// 刷新数据明细数据
    /// </summary>
    public void RefreshCheckData(List<string> request)
    {
        DataSet ds = new DataSet();
        System.Data.DataTable dt = new System.Data.DataTable();
        WedoctorFileData wd = new WedoctorFileData();
        List<string[]> response = getDataList(request);
        sum_totalCount = response.Count;
        dt.Columns.Add("交易时间", typeof(string));
        dt.Columns.Add("业务平台流水", typeof(string));
        dt.Columns.Add("平台交易流水", typeof(string));
        dt.Columns.Add("业务退款流水", typeof(string));
        dt.Columns.Add("平台退款流水", typeof(string));
        dt.Columns.Add("交易金额", typeof(decimal));
        dt.Columns.Add("退款金额", typeof(decimal));
        dt.Columns.Add("补贴金额", typeof(decimal));
        dt.Columns.Add("实付金额", typeof(decimal));
        dt.Columns.Add("实退金额", typeof(decimal));
        dt.Columns.Add("第三方支付交易流水号", typeof(string));
        dt.Columns.Add("第三方支付退款流水号", typeof(string));
        dt.Columns.Add("支付类型", typeof(string));
        dt.Columns.Add("交易状态", typeof(string));
        dt.Columns.Add("退款状态", typeof(string));
        dt.Columns.Add("商户名称", typeof(string));
        dt.Columns.Add("商品名称", typeof(string));
        dt.Columns.Add("商户号", typeof(string));
        dt.Columns.Add("接入应用ID", typeof(string));
        dt.Columns.Add("第三方商户号", typeof(string));
        for (int k = 0; k < response.Count; k++)
        {
              dt.Rows.Add(response[k]);

              response.Remove(response[k]);
       


        }

        this.GridView.DataSource = dt;
        this.GridView.DataBind(); 
    }
      
#endregion
    /// <summary>
    /// 获取his交易数据
    /// </summary>
    /// <returns></returns>
    public string gethisXml(string request)
    {
        string response = GetDBdata.gethis(request);
        return response;
    }
   
    /// <summary>
    /// 获取平台交易明细账数据
    /// </summary>
    /// <returns></returns>
    public List<string[]> getDataList(List<string> listdate)
    {
        List<string[]> list = new List<string[]>();
        List<string[]> response = new List<string[]>();

        foreach (var date in listdate)
        {
            list = GetDBdata.getPtData(date);
            if (list.Count != 0)
            {
                list.RemoveAt(0);
                list.RemoveAt((list.Count - 3));
                list.RemoveAt((list.Count - 2));
                list.RemoveAt((list.Count - 1));

                foreach (var str in list)
                {
                    response.Add(str);
                }
            }
        }
        return response;
    }
    
   
    /// <summary>
    /// 获取his入参
    /// </summary>
    public string gethisReq(string begindata, string enddata)
    {
        string req = string.Empty;
        string request = string.Empty;
        string pagesize = ConfigurationManager.AppSettings["PageSize"];//ReadIni.ReadIniValue("LOCALHOST_SERVERS", "PageSize");//HIS接口数据查询量
        string hiskey = ConfigurationManager.AppSettings["Hiskey"];//ReadIni.ReadIniValue("LOCALHOST_SERVERS", "Hiskey");//His密匙
        string service = ConfigurationManager.AppSettings["Service"];//ReadIni.ReadIniValue("LOCALHOST_SERVERS", "Service");//接口名称
        string partner = ConfigurationManager.AppSettings["Partner"];//ReadIni.ReadIniValue("LOCALHOST_SERVERS", "Partner");//接入方接口用户
        string hospitalCode = ConfigurationManager.AppSettings["HospitalCode"];//ReadIni.ReadIniValue("LOCALHOST_SERVERS", "HospitalCode");//接入医疗机构编码


        req = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<request>
  <startDate><![CDATA[" + begindata + @" ]]></startDate>
  <endDate><![CDATA[" + enddata + @"]]></endDate>
  <currentPage><![CDATA[1]]></currentPage>
  <pageSize><![CDATA[" + pagesize + @"]]></pageSize>
</request>";

        string encryptKey = hiskey;
        string encryptString = req;
        req = AES.Encrypt(encryptKey, encryptString);

        IDictionary<string, string> dict = new Dictionary<string, string>();
        string sign = string.Empty;

        dict.Add("service", service);
        dict.Add("partner", partner);
        dict.Add("hospitalCode", hospitalCode);
        dict.Add("inputCharset", "utf-8");
        dict.Add("dataFormat", "xml");
        dict.Add("requestEncrypted", req);
        string signString = GetDBdata.CreateLinkString(GetDBdata.SortDictPara(dict));
        signString += "&key=" + encryptKey;
        sign = GetDBdata.Encode(signString).ToUpper();

        request = @"<root>
                          <service><![CDATA[" + service + @"]]></service>
                          <partner><![CDATA[" + partner + @"]]></partner>
                          <hospitalCode><![CDATA[" + hospitalCode + @"]]></hospitalCode>
                          <inputCharset><![CDATA[utf-8]]></inputCharset>
                          <dataFormat><![CDATA[xml]]></dataFormat>
                          <sign><![CDATA[" + sign + @"]]></sign>
                          <signType><![CDATA[md5]]></signType>
                          <requestEncrypted><![CDATA[" + req + @"]]></requestEncrypted>
                        </root>";
        return request;
    }
  

    
    /// <summary>
    /// 获取平台入参
    /// </summary>
    public List<string> getReq(string begindata, string enddata)
    {
        string request = string.Empty;
        string date = string.Empty;
        DateTime dtend = Convert.ToDateTime(enddata + " 00:00:00");
        DateTime dtbegin = Convert.ToDateTime(begindata + " 00:00:00");
       TimeSpan tsend = new TimeSpan(dtend.Ticks);
        TimeSpan tsbegin = new TimeSpan(dtbegin.Ticks);
        TimeSpan ts = tsend.Subtract(tsbegin).Duration();
        int n = ts.Days + 1;

        List<string> listdate = new List<string>();
        for (int i = 0; i < n; i++)
        {
            date = dtbegin.AddDays(i).ToString("yyyyMMdd");
            listdate.Add(date);
        }
        return listdate;
    }
    
}